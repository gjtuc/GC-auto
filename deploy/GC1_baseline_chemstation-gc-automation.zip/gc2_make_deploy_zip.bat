@echo off
chcp 949 >nul
setlocal
cd /d "%~dp0"

set "DEST=%~dp0deploy\GC2_baseline_chemstation-gc-automation.zip"
if not exist "%~dp0deploy" mkdir "%~dp0deploy"
if exist "%DEST%" del /f /q "%DEST%"

echo.
echo  GC2 baseline zip 만들기 (역배포용)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy\make_gc2_baseline_zip.ps1"
if errorlevel 1 (
    echo [오류] zip 생성 실패
    pause
    exit /b 1
)

set "DESKTOP_KCH=%USERPROFILE%\Desktop\KCH"
if not exist "%DESKTOP_KCH%" mkdir "%DESKTOP_KCH%"
copy /y "%DEST%" "%DESKTOP_KCH%\GC2_baseline_chemstation-gc-automation.zip" >nul

echo.
echo  [완료] %DEST%
echo  [복사] %DESKTOP_KCH%\GC2_baseline_chemstation-gc-automation.zip
echo.
echo  GC2 PC에서:
echo    1. zip 풀기 -^> C:\Users\User\chemstation-gc-automation
echo    2. deploy\gc_automation.env.gc2 -^> Desktop\KCH\gc_automation.env
echo    3. gc_verify.bat / gc_start_watch.bat
echo.
pause
