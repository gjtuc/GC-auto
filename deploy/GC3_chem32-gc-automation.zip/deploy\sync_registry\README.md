# PC 동기화 기록 (sync_registry)

## 목적

GitHub `GC-auto` repo를 **어느 PC가 언제 올렸고(pull/push), 누가 최신인지** 추적합니다.

## 필수 규칙

**한 PC가 GitHub에 최신본을 올렸다면, 다른 PC는 `gc_git_pull.bat`으로 받은 뒤에만 수정·push 합니다.**  
pull 없이 push하면 **다른 PC 수정이 덮어씌워지거나 날아갈 수 있습니다.**

| 순서 | 명령 |
|------|------|
| 작업 시작 | `gc_git_pull.bat` |
| 현황 확인 | `gc_git_status.bat` → `SYNC_STATUS.md` |
| `[WARN] need pull` | push/수정 **중단** → pull 먼저 |

| 파일 | 설명 |
|------|------|
| `{COMPUTERNAME}.json` | **PC마다 1개** — 본인 PC만 갱신 (충돌 적음) |
| `EXPECTED_PCS.json` | 연구실에 있어야 할 PC 목록 (수동 편집) |
| `../SYNC_STATUS.md` | **자동 생성** — 전 PC 현황 표 (직접 수정 금지) |

## 자동 갱신 시점

| 이벤트 | 스크립트 |
|--------|----------|
| **push** (코드 올림) | `.cursor/hooks` stop → `scripts/git_auto_sync.ps1 -Mode stop` |
| **pull** (코드 받음) | `gc_git_begin.bat` / `gc_git_pull.bat` / Cursor sessionStart |

## PC에서 할 일

```powershell
# 작업 시작 — 반드시 pull (동기화 기록 포함)
.\gc_git_pull.bat

# 현황만 확인
.\gc_git_status.bat
```

## 상태 표시 (SYNC_STATUS.md)

| 표시 | 의미 |
|------|------|
| ✅ 최신 | `last_pull_commit` == repo HEAD |
| ⚠ pull 필요 | 다른 PC가 push 함 — `git pull` |
| 📤 push만 함 | 이 PC는 올렸지만 pull 기록 없음 |
| ❓ 미등록 | EXPECTED_PCS 에는 있으나 json 없음 — 한 번 pull/push |
| — | EXPECTED_PCS 에 없음 — EXPECTED_PCS.json 에 추가 |

## machine_profile 과의 관계

- `Desktop\박은규\machine_profile.json` (GC1 장비 PC)
- `Desktop\KCH\machine_profile.json` (GC2/GC3 장비 PC)
- `Desktop\.cursor\KCH\machine_profile.json` (은규 PC / 차헌 PC)

→ sync_registry.ps1 이 있으면 operator/role 자동 채움.

상세: `docs/SYNC_TRACKING.md`
